"""
Week 2 - Python for Data Analytics
Next Gen Software Hub Pvt. Ltd.

Sales Data Analysis Project
"""

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# ---------------------------------------------------------
# 1. Locate the dataset safely
# ---------------------------------------------------------
BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "sales_data.csv"
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

if not DATA_FILE.exists():
    raise FileNotFoundError(
        "sales_data.csv was not found. "
        "Keep sales_analysis.py and sales_data.csv in the same folder."
    )


# ---------------------------------------------------------
# 2. Load data
# ---------------------------------------------------------
df = pd.read_csv(DATA_FILE, parse_dates=["Date"])

print("=" * 60)
print("WEEK 2 - SALES DATA ANALYSIS")
print("=" * 60)
print(f"Dataset records: {len(df)}")


# ---------------------------------------------------------
# 3. Basic data inspection and cleaning
# ---------------------------------------------------------
print("\nFIRST 5 RECORDS")
print(df.head())

print("\nDATA TYPES")
print(df.dtypes)

print("\nMISSING VALUES")
print(df.isnull().sum())

# Remove duplicate rows.
df = df.drop_duplicates().copy()

# Convert numeric columns safely.
numeric_columns = [
    "Quantity",
    "Unit_Price",
    "Discount",
    "Revenue",
]

for column in numeric_columns:
    df[column] = pd.to_numeric(df[column], errors="coerce")

# Fill missing numeric values if they exist.
df["Quantity"] = df["Quantity"].fillna(df["Quantity"].median())
df["Unit_Price"] = df["Unit_Price"].fillna(df["Unit_Price"].median())
df["Discount"] = df["Discount"].fillna(0)

# Recalculate revenue to ensure consistency.
df["Revenue"] = (
    df["Quantity"]
    * df["Unit_Price"]
    * (1 - df["Discount"])
)


# ---------------------------------------------------------
# 4. NumPy analysis
# ---------------------------------------------------------
quantity_array = df["Quantity"].to_numpy()

print("\nNUMPY ANALYSIS")
print(f"Mean quantity   : {np.mean(quantity_array):.2f}")
print(f"Minimum quantity: {np.min(quantity_array):.0f}")
print(f"Maximum quantity: {np.max(quantity_array):.0f}")


# ---------------------------------------------------------
# 5. Pandas data manipulation and analysis
# ---------------------------------------------------------
product_analysis = (
    df.groupby("Product", as_index=False)
    .agg(
        Total_Quantity=("Quantity", "sum"),
        Total_Revenue=("Revenue", "sum"),
        Average_Revenue=("Revenue", "mean"),
    )
    .sort_values("Total_Revenue", ascending=False)
)

region_analysis = (
    df.groupby("Region", as_index=False)
    .agg(
        Total_Quantity=("Quantity", "sum"),
        Total_Revenue=("Revenue", "sum"),
    )
    .sort_values("Total_Revenue", ascending=False)
)

df["Month"] = df["Date"].dt.to_period("M").astype(str)

monthly_analysis = (
    df.groupby("Month", as_index=False)
    .agg(
        Total_Quantity=("Quantity", "sum"),
        Total_Revenue=("Revenue", "sum"),
    )
)


# ---------------------------------------------------------
# 6. Display results
# ---------------------------------------------------------
print("\nPRODUCT ANALYSIS")
print(product_analysis.to_string(index=False))

print("\nREGION ANALYSIS")
print(region_analysis.to_string(index=False))

print("\nMONTHLY ANALYSIS")
print(monthly_analysis.to_string(index=False))

print("\nOVERALL RESULTS")
print(f"Total revenue       : ₹{df['Revenue'].sum():,.2f}")
print(f"Average order value : ₹{df['Revenue'].mean():,.2f}")
print(f"Total quantity sold : {df['Quantity'].sum():,.0f}")
print(f"Highest revenue product: {product_analysis.iloc[0]['Product']}")
print(f"Highest revenue region  : {region_analysis.iloc[0]['Region']}")


# ---------------------------------------------------------
# 7. Save analysis tables
# ---------------------------------------------------------
df.to_csv(OUTPUT_DIR / "cleaned_sales_data.csv", index=False)
product_analysis.to_csv(OUTPUT_DIR / "product_analysis.csv", index=False)
region_analysis.to_csv(OUTPUT_DIR / "region_analysis.csv", index=False)
monthly_analysis.to_csv(OUTPUT_DIR / "monthly_analysis.csv", index=False)


# ---------------------------------------------------------
# 8. Create visualizations using Matplotlib
# ---------------------------------------------------------
plt.figure(figsize=(10, 5))
plt.bar(product_analysis["Product"], product_analysis["Total_Revenue"])
plt.title("Revenue by Product")
plt.xlabel("Product")
plt.ylabel("Revenue")
plt.xticks(rotation=35)
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "revenue_by_product.png", dpi=160)
plt.close()


plt.figure(figsize=(8, 5))
plt.bar(region_analysis["Region"], region_analysis["Total_Revenue"])
plt.title("Revenue by Region")
plt.xlabel("Region")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "revenue_by_region.png", dpi=160)
plt.close()


plt.figure(figsize=(8, 5))
plt.plot(
    monthly_analysis["Month"],
    monthly_analysis["Total_Revenue"],
    marker="o",
)
plt.title("Monthly Revenue Trend")
plt.xlabel("Month")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig(OUTPUT_DIR / "monthly_revenue_trend.png", dpi=160)
plt.close()


print("\nSUCCESS")
print(f"All output files were saved to: {OUTPUT_DIR}")
